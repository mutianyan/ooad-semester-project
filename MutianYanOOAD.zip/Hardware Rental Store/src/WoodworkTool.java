
public class WoodworkTool extends Tool{

	public WoodworkTool(String name) {
		super(name);
		
		// TODO Auto-generated constructor stub
	}

	@Override
	public void setPrice() {
		this.price = 20;
		
	}

	@Override
	public void setCategory() {
		this.category = "wood";
		
	}

}
