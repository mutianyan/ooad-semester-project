
public class BusinessCustomer extends Customer{

	public BusinessCustomer(String type, String name) {
		super(type, name);
		// TODO Auto-generated constructor stub
		this.availableNum = 3;
	}
	

}
