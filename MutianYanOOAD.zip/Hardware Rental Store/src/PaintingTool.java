
public class PaintingTool extends Tool {

	public PaintingTool(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void setPrice() {
		this.price = 5.0;
		
	}

	@Override
	public void setCategory() {
		this.category = "painting";
		
	}


}
