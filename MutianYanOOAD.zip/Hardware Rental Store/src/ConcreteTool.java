
public class ConcreteTool extends Tool {

	public ConcreteTool(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void setPrice() {
		this.price = 10.0;
		
	}

	@Override
	public void setCategory() {
		// TODO Auto-generated method stub
		this.category="concrete";
		
	}


}