
public class YardworkTool extends Tool{

	public YardworkTool(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void setPrice() {
		this.price =20.0;
		
	}

	@Override
	public void setCategory() {
		this.category="yard";
		
	}

}
