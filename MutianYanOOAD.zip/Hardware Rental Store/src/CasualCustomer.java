
public class CasualCustomer extends Customer {

	public CasualCustomer(String type, String name) {
		super(type, name);
		// TODO Auto-generated constructor stub
		this.availableNum = 2;
	}

}
